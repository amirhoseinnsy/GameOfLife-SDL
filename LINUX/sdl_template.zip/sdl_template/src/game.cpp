#include <iostream>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>



#define F first
#define S second
#define HEIGHT 400
#define WIDTH 400
#define PANEL_WIDTH 100
#define N 4
#define CELL_COLOR Color{49, 173, 82, 255}
#define SELECTED_COLOR Color{209, 50, 69, 255}

#ifdef main
#undef main
#endif

using namespace std;

struct Color{
    int r;
    int g;
    int b;
    int a;
};

class Button{
public:
    Button(){
        size = {0, 0};
    }
    Button(pair<int, int> _pos, pair<int, int> _size, Color _color){
        pos = _pos;
        size = _size;
        color = _color;
        rect = {pos.F, pos.S, size.F, size.S}; 
    }
    
    void draw(SDL_Renderer *renderer){
        SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
        SDL_RenderFillRect(renderer, &rect);
    }

    bool is_Clicked(pair<int, int> _pos){
        if (_pos.F > pos.F && _pos.F < (pos.F + size.F) && _pos.S > pos.S && _pos.S < pos.S + size.S)
            return true;
        else
            return false;
    }

    pair<int, int> pos;
    pair<int, int> size;
    Color color; 
    SDL_Rect rect; 
};

class Speed{
public:
    SDL_Window *window;
    SDL_Renderer* rend;
    SDL_Event event;
    int cnt;
    bool board[N][N];
    Button *button_board[N][N];
    TTF_Font * font;
    SDL_Color text_color;
    SDL_Surface* image_sur;
    Button refresh;


    Speed(){
        if (SDL_Init(SDL_INIT_EVERYTHING) != 0){
            printf("Error initializing SDL: %s\n", SDL_GetError());
            return;
        }
        window = SDL_CreateWindow("game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH + PANEL_WIDTH, HEIGHT, 0);
        if (!window){
            printf("Error creating window: %s\n", SDL_GetError());
            SDL_Quit();
            return;
        }
        Uint32 render_flags = SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;
        rend = SDL_CreateRenderer(window, -1, render_flags);
        if (!rend){
            printf("Error creating renderer: %s\n", SDL_GetError());
            SDL_DestroyWindow(window);
            SDL_Quit();
            return;
        }

        if (TTF_Init() < 0 ) {
            cout << "Error initializing SDL_ttf: " << TTF_GetError() << endl;
            SDL_Quit();
            return;
        }

        if (IMG_Init(IMG_INIT_PNG) == 0) {
            std::cout << "Error SDL2_image Initialization";
            return;
        }

        for (int i = 0; i < N; i++){
            for (int j = 0; j < N; j++){
                button_board[i][j] = new Button({i * (WIDTH / N), j * (HEIGHT / N)}, {WIDTH / N, HEIGHT / N}, CELL_COLOR);
                board[i][j] = false;
            }
        }
        refresh = Button({WIDTH, 100}, {100, 100}, Color{0, 0, 0, 0});

        //select one cell
        int x = rand() % N, y = rand() % N;
        board[x][y] = true;
        button_board[x][y]->color = SELECTED_COLOR;
        
        //loading font
        font = TTF_OpenFont("Arial.ttf", 25);
        text_color = SDL_Color{0, 0, 0};
        cnt = 0;

        //loading image
        image_sur = IMG_Load("refresh.png");
    }

    void draw(){

        //rendering buttons
        for (int i = 0; i < N; i++){
            for (int j = 0; j < N; j++)
                button_board[i][j]->draw(rend);
        }
        
        //rendering lines
        SDL_SetRenderDrawColor(rend, 0, 0, 0, 255);
        for (int i = 0; i < N; i++){
            SDL_RenderDrawLine(rend, i * (WIDTH / N), 0, i * (WIDTH / N), HEIGHT);
            SDL_RenderDrawLine(rend, 0, i * (HEIGHT / N), WIDTH, i * (HEIGHT / N));
        }

        //rendering image
        SDL_Texture* image_tex = SDL_CreateTextureFromSurface(rend, image_sur);
        int imgW = 0;
        int imgH = 0;
        SDL_QueryTexture(image_tex, NULL, NULL, &imgW, &imgH);
        SDL_Rect img_rect = {WIDTH, 100, imgW, imgH};
        SDL_RenderCopy(rend, image_tex, NULL, &img_rect);


        //rendering text
        SDL_Surface * surface = TTF_RenderText_Solid(font, to_string(cnt).c_str(), text_color);
        SDL_Texture * texture = SDL_CreateTextureFromSurface(rend, surface);
        int texW = 0;
        int texH = 0;
        SDL_QueryTexture(texture, NULL, NULL, &texW, &texH);
        SDL_Rect dstrect = {WIDTH + PANEL_WIDTH / 3, 20, texW, texH };
        SDL_RenderCopy(rend, texture, NULL, &dstrect);
    }

    void run(){
        bool running = true;
        bool lock = false;
        while(running){
            while(SDL_PollEvent(&event)){
                if (event.type == SDL_QUIT){
                    running = false;
                    SDL_Quit();
                    break;
                }
                if (event.type == SDL_MOUSEBUTTONDOWN && !lock){
                    lock = true;
                    handle_click(event.motion.x, event.motion.y);
                }
                if (event.type == SDL_MOUSEBUTTONUP && lock)
                    lock = false;
            }
            SDL_SetRenderDrawColor(rend, 18, 219, 159, 255);
            SDL_RenderClear(rend);
            draw();
            SDL_RenderPresent(rend);
        }
    }

    void handle_click(int x, int y){
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                if (button_board[i][j]->is_Clicked({x, y}))
                    if(board[i][j]){
                        board[i][j] = false;
                        int x = rand() % N, y = rand() % N;
                        board[x][y] = true;
                        button_board[i][j]->color = CELL_COLOR;
                        button_board[x][y]->color = SELECTED_COLOR;
                        cnt++;
                    }
        if (refresh.is_Clicked({x, y})){
            cnt = 0;
        }
    }



};


int main(int argc, char* argv[]){
    Speed speed = Speed();
    speed.run();
    return 0;
}