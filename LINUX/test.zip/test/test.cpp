#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>



#define F first
#define S second
#define PB push_back
#define WIDTH 300
#define HEIGHT 300

using namespace std;

int main(int argc, char* argv[]){
    if (SDL_Init(SDL_INIT_EVERYTHING) != 0){
        printf("Error initializing SDL: %s\n", SDL_GetError());
        return 0;
    }

    if (IMG_Init(IMG_INIT_PNG) == 0) {
        std::cout << "Error SDL2_image Initialization";
        return 0;
    }   

    TTF_Init();

    SDL_Window* window = SDL_CreateWindow("game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, 0);
    if (!window){
        printf("Error creating window: %s\n", SDL_GetError());
        SDL_Quit();
        return 0;
    }
    Uint32 render_flags = SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;
    SDL_Renderer* rend = SDL_CreateRenderer(window, -1, render_flags);
    if (!rend){
        printf("Error creating renderer: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 0;
    }
    SDL_Event event;

    bool running = true;
    while(running){
        while(SDL_PollEvent(&event)){
            if (event.type == SDL_QUIT){
                running = false;
                SDL_Quit();
                break;
            }
        }
        SDL_SetRenderDrawColor(rend, 0, 0, 0, 255);
        SDL_RenderClear(rend);

        SDL_SetRenderDrawColor(rend, 255, 255, 255, 255);
        SDL_Rect rect = {100, 0, 100, 100};
        SDL_RenderFillRect(rend, &rect);

        //line
        SDL_RenderDrawLine(rend, 30, 0, 100, 100);

        //image
        SDL_Surface* image_sur = IMG_Load("refresh.png");
        SDL_Texture* image_tex = SDL_CreateTextureFromSurface(rend, image_sur);
        int imgW = 0;
        int imgH = 0;
        SDL_QueryTexture(image_tex, NULL, NULL, &imgW, &imgH);
        SDL_Rect img_rect = {100, 100, imgW, imgH};
        SDL_RenderCopy(rend, image_tex, NULL, &img_rect);

        //text
        TTF_Font *font = TTF_OpenFont("Arial.ttf", 25);
        SDL_Surface * surface = TTF_RenderText_Solid(font, "Project", SDL_Color{255, 250, 0, 255});
        SDL_Texture * texture = SDL_CreateTextureFromSurface(rend, surface);
        int texW = 0;
        int texH = 0;
        SDL_QueryTexture(texture, NULL, NULL, &texW, &texH);
        SDL_Rect dstrect = {200, 200, texW, texH};
        SDL_RenderCopy(rend, texture, NULL, &dstrect);


        SDL_RenderPresent(rend);
    }


    return 0;
}




